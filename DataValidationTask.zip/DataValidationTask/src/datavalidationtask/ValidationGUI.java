package datavalidationtask;

import com.github.lgooddatepicker.components.DatePickerSettings;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.time.*;
import java.time.format.*;
import javax.imageio.ImageIO;
import javax.swing.*;

/**
 *
 * @author Herman Spies 2022
 */
public class ValidationGUI extends javax.swing.JFrame {

    private String idNum = "";      //The ID number of the user
    private int age = 0;            //The user entered age
    private boolean gender = false; //0 = male, 1 = female
    private LocalDate DOB;          //The Date of Birth of the user
    private String country = "";    //The country of origin of the individual

    //String version of all the non-string variables. Used before the type test
    private String strAge = "0";
    private String strGender = "None";

    /**
     * Creates new form ValidationGUI
     */
    public ValidationGUI() {
        initComponents();

        //Set frame icon
        this.setIconImage(new ImageIcon("SA coat of arms icon.png").getImage());

        //Constrains the pickable Date of Birth
        DatePickerSettings dateSettings = dtpDOB.getSettings();
        dateSettings.setAllowEmptyDates(false);
        dateSettings.setDateRangeLimits(LocalDate.now().minusYears(150),
                LocalDate.now());

        resetErrors();
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        btnGroupGender = new javax.swing.ButtonGroup();
        lblTitle = new javax.swing.JLabel();
        lblIDNum = new javax.swing.JLabel();
        txfIDNum = new javax.swing.JTextField();
        lblIDNumError = new javax.swing.JLabel();
        lblAge = new javax.swing.JLabel();
        txfAge = new javax.swing.JTextField();
        lblAgeError = new javax.swing.JLabel();
        lblGender = new javax.swing.JLabel();
        radioMale = new javax.swing.JRadioButton();
        radioFemale = new javax.swing.JRadioButton();
        lblGenderError = new javax.swing.JLabel();
        lblDOB = new javax.swing.JLabel();
        dtpDOB = new com.github.lgooddatepicker.components.DatePicker();
        lblDOBError = new javax.swing.JLabel();
        lblCountry = new javax.swing.JLabel();
        comboCountry = new javax.swing.JComboBox<>();
        txfCountry = new javax.swing.JTextField();
        lblCountryError = new javax.swing.JLabel();
        btnValidate = new javax.swing.JButton();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
        setTitle("SA ID checker");
        setLocationByPlatform(true);
        setName("MainFrame"); // NOI18N
        setResizable(false);
        addWindowListener(new java.awt.event.WindowAdapter() {
            public void windowClosing(java.awt.event.WindowEvent evt) {
                formWindowClosing(evt);
            }
        });

        lblTitle.setHorizontalAlignment(javax.swing.SwingConstants.CENTER);
        lblTitle.setText("South African ID number checker");
        lblTitle.setFont(new java.awt.Font("Segoe UI", 0, 36)); // NOI18N

        lblIDNum.setText("Enter your ID number:");

        lblIDNumError.setText("Error");
        lblIDNumError.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblIDNumError.setForeground(new java.awt.Color(255, 0, 0));

        lblAge.setText("Enter your age:");

        lblAgeError.setText("Error");
        lblAgeError.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblAgeError.setForeground(new java.awt.Color(255, 0, 0));

        lblGender.setText("Select your birth gender:");

        btnGroupGender.add(radioMale);
        radioMale.setText("Male");

        btnGroupGender.add(radioFemale);
        radioFemale.setText("Female");

        lblGenderError.setText("Error");
        lblGenderError.setForeground(new java.awt.Color(255, 0, 0));

        lblDOB.setText("Enter your date of birth:");

        lblDOBError.setText("Error");
        lblDOBError.setVerticalAlignment(javax.swing.SwingConstants.TOP);
        lblDOBError.setForeground(new java.awt.Color(255, 0, 0));

        lblCountry.setText("What is your birth country?");

        comboCountry.setModel(new javax.swing.DefaultComboBoxModel<>(new String[] { "South Africa", "Other" }));
        comboCountry.addItemListener(new java.awt.event.ItemListener() {
            public void itemStateChanged(java.awt.event.ItemEvent evt) {
                comboCountryItemStateChanged(evt);
            }
        });

        txfCountry.setEnabled(false);

        lblCountryError.setText("Error");
        lblCountryError.setForeground(new java.awt.Color(255, 0, 0));

        btnValidate.setText("Check my ID");
        btnValidate.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                validate(evt);
            }
        });

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(150, 150, 150)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(lblIDNum)
                            .addComponent(lblDOB)
                            .addComponent(lblAge)
                            .addComponent(lblGender))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txfIDNum, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(txfAge, javax.swing.GroupLayout.PREFERRED_SIZE, 75, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(radioMale)
                                    .addComponent(radioFemale)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(18, 18, 18)
                                .addComponent(dtpDOB, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(lblAgeError)
                                    .addComponent(lblGenderError)
                                    .addComponent(lblIDNumError)))
                            .addGroup(layout.createSequentialGroup()
                                .addGap(5, 5, 5)
                                .addComponent(lblCountryError))
                            .addGroup(layout.createSequentialGroup()
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblDOBError))))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(245, 245, 245)
                        .addComponent(btnValidate))
                    .addGroup(layout.createSequentialGroup()
                        .addGap(37, 37, 37)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addGap(99, 99, 99)
                                .addComponent(lblCountry)
                                .addGap(18, 18, 18)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                                    .addComponent(txfCountry, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(comboCountry, javax.swing.GroupLayout.PREFERRED_SIZE, 150, javax.swing.GroupLayout.PREFERRED_SIZE)))
                            .addComponent(lblTitle))))
                .addContainerGap(58, Short.MAX_VALUE))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addComponent(lblTitle)
                .addGap(18, 18, 18)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(lblIDNum)
                        .addComponent(txfIDNum, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                    .addComponent(lblIDNumError, javax.swing.GroupLayout.PREFERRED_SIZE, 30, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                        .addComponent(txfAge, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addComponent(lblAge))
                    .addComponent(lblAgeError, javax.swing.GroupLayout.PREFERRED_SIZE, 31, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addGap(9, 9, 9)
                        .addComponent(lblGender)
                        .addGap(56, 56, 56)
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                            .addComponent(comboCountry, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                            .addGroup(layout.createSequentialGroup()
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.TRAILING)
                                    .addComponent(lblCountry, javax.swing.GroupLayout.Alignment.LEADING, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                                    .addGroup(layout.createSequentialGroup()
                                        .addGap(17, 23, Short.MAX_VALUE)
                                        .addComponent(txfCountry, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)))
                                .addGap(11, 11, 11)))
                        .addGap(62, 62, 62)
                        .addComponent(btnValidate)
                        .addGap(52, 52, 52))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(radioMale, javax.swing.GroupLayout.PREFERRED_SIZE, 16, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                                .addComponent(radioFemale, javax.swing.GroupLayout.PREFERRED_SIZE, 19, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                                    .addComponent(dtpDOB, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                                    .addComponent(lblDOB)))
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(lblGenderError, javax.swing.GroupLayout.PREFERRED_SIZE, 29, javax.swing.GroupLayout.PREFERRED_SIZE)
                                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                                .addComponent(lblDOBError, javax.swing.GroupLayout.PREFERRED_SIZE, 37, javax.swing.GroupLayout.PREFERRED_SIZE)))
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(lblCountryError, javax.swing.GroupLayout.PREFERRED_SIZE, 46, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))))
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    /**
     * Validates all user input. If any check fails, return. Also calls
     * resetErrors()
     *
     * @param evt
     */
    private void validate(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_validate

        resetErrors();

        if (!presenceCheck()) {
            JOptionPane.showMessageDialog(this, "One or more fields are empty",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!typeCheck()) {
            JOptionPane.showMessageDialog(this, "One or more fields aren't numbers",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!lengthCheck()) {
            JOptionPane.showMessageDialog(this, "The ID number is the wrong length",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!checkDigit()) {
            JOptionPane.showMessageDialog(this, "The check digit is incorrect",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!compareIDToInput()) {
            JOptionPane.showMessageDialog(this, "ID doesn't match entered values",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }
        if (!ageMatch()) {
            JOptionPane.showMessageDialog(this, "Age doesn't match",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JOptionPane.showMessageDialog(this, "ID valid", "Congradulations",
                JOptionPane.INFORMATION_MESSAGE);
    }//GEN-LAST:event_validate

    /**
     * Changes whether the user can enter their country's name based on if the
     * combo box has "South Africa" selected or not
     *
     * @param evt
     */
    private void comboCountryItemStateChanged(java.awt.event.ItemEvent evt) {//GEN-FIRST:event_comboCountryItemStateChanged
        boolean enabled = comboCountry.getSelectedItem().equals("Other");
        txfCountry.setEnabled(enabled);
    }//GEN-LAST:event_comboCountryItemStateChanged

    /**
     * Used for making the Word document to include screenshots of the window
     *
     * @param evt
     */
    private void formWindowClosing(java.awt.event.WindowEvent evt) {//GEN-FIRST:event_formWindowClosing
        //Commented for your conveniance

//        BufferedImage img = new BufferedImage(this.getWidth(), this.getHeight(), BufferedImage.TYPE_INT_RGB);
//        this.paint(img.getGraphics());
//        File outputfile = new File("Screenshot.png");
//
//        try {
//            ImageIO.write(img, "png", outputfile);
//            System.out.println("Successfully saved");
//        } catch (IOException e) {
//            System.out.println("Couldn't save screenshot");
//        }
    }//GEN-LAST:event_formWindowClosing

    /**
     * Sets the look and feel to the system default
     *
     * @param args the command line arguments
     */
    public static void main(String args[]) {
        /* Set the System look and feel */
        //<editor-fold defaultstate="collapsed" desc=" Look and feel setting code (optional) ">
        /* If Nimbus (introduced in Java SE 6) is not available, stay with the default look and feel.
         * For details see http://download.oracle.com/javase/tutorial/uiswing/lookandfeel/plaf.html 
         */
        try {
//            for (javax.swing.UIManager.LookAndFeelInfo info : javax.swing.UIManager.getInstalledLookAndFeels()) {
//                if ("Nimbus".equals(info.getName())) {
//                    javax.swing.UIManager.setLookAndFeel(info.getClassName());
//                    break;
//                }
//            }
            UIManager.setLookAndFeel(UIManager.getSystemLookAndFeelClassName());
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(ValidationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(ValidationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(ValidationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(ValidationGUI.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
        //</editor-fold>

        /* Create and display the form */
        java.awt.EventQueue.invokeLater(new Runnable() {
            public void run() {
                new ValidationGUI().setVisible(true);
            }
        });
    }

    /**
     * Checks whether all fields contain a value. Gives a value to all empty
     * fields' error labels to alert the user to their presence.
     *
     * @return True if all values are entered
     */
    private boolean presenceCheck() {
        boolean correct = true;     //False if ANY field is empty

        try {
            boolean oneIncorrect;   //True if the last checked field is empty

            //Load all the variables
            strAge = txfAge.getText();
            if (radioFemale.isSelected() || radioMale.isSelected()) {
                gender = radioFemale.isSelected();
                strGender = gender ? "Female" : "Male";
            } else {
                strGender = "None";
            }

            if (comboCountry.getSelectedItem().equals("South Africa")) {
                country = "South Africa";
            } else {
                country = txfCountry.getText();
            }

            idNum = txfIDNum.getText();

            DOB = dtpDOB.getDate();

            //Check the age field
            oneIncorrect = strAge == null || strAge.length() == 0;

            if (oneIncorrect) {
                lblAgeError.setText("Please provide your age");
                correct = oneIncorrect = false;
            }

            //Check the country field
            oneIncorrect = country == null || country.length() == 0;

            if (oneIncorrect) {
                lblCountryError.setText("<html>Please enter your country "
                        + "of origin</html>");
                correct = oneIncorrect = false;
            }

            //I don't have to check the DOB, since it does its own validation
            //Check the gender
            oneIncorrect = strGender.equals("None");

            if (oneIncorrect) {
                lblGenderError.setText("<html>Please choose the most correct "
                        + "one</html>");
                correct = oneIncorrect = false;
            }

            //Check the ID number
            oneIncorrect = idNum == null || idNum.length() == 0;

            if (oneIncorrect) {
                lblIDNumError.setText("Please enter your ID number");
                correct = oneIncorrect = false;
            }
        } catch (NullPointerException nlptn) {
            JOptionPane.showMessageDialog(this, "Something doesn't exist",
                    "Error", JOptionPane.ERROR_MESSAGE);
            return false;
        }

        return correct;
    }

    /**
     * Checks whether all fields are the correct length. Gives a value to all
     * fields with incorrect lengths' error labels to alert the user to their
     * presence.
     *
     * @return True if all length specific fields are the correct length
     */
    private boolean lengthCheck() {
        boolean correct = true;

        //Check the ID number's length
        correct = idNum.length() == 13;

        if (!correct) {
            lblIDNumError.setText("<html>Your ID number must be"
                    + "13 digits long</html>");
        }

        return correct;
    }

    /**
     * Checks whether all fields contain the correct data type. Gives a value to
     * all incorrect fields' error labels to alert the user to their presence.
     *
     * @return True if all text fields contain the right data type
     */
    private boolean typeCheck() {
        boolean correct = true;
        boolean oneIncorrect = false;

        //Check the ID number
        oneIncorrect = !isInteger(idNum);

        if (oneIncorrect) {
            lblIDNumError.setText("Please only enter a number");
            correct = oneIncorrect = false;
        }

        //Check the age
        oneIncorrect = !isInteger(strAge);

        if (oneIncorrect) {
            lblAgeError.setText("Please only enter a number");
            correct = oneIncorrect = false;
        } else {
            age = Integer.parseInt(strAge);
        }

        return correct;
    }

    /**
     * Checks whether the check digit is correct. Alerts the user if it is
     * incorrect. See
     * https://en.wikipedia.org/wiki/Luhn_algorithm#Example_for_validating_check_digit
     *
     * @return True if the ID's check digit is correct
     */
    private boolean checkDigit() {
        String num = idNum.substring(0, 12);
        int sum = 0;

        for (int i = 0; i < num.length(); i++) {
            int c = num.charAt(num.length() - i - 1) - 48;

            c *= 2 - (i % 2);

            if (c >= 10) {
                int digitSum = (int) Math.floor(c / 10d) + c % 10;
                sum += digitSum;
            } else {
                sum += c;
            }
        }

        int checkDigit = (10 - (sum % 10)) % 10;

        boolean correct = (idNum.charAt(12) - 48) == checkDigit;

        if (!correct) {
            lblIDNumError.setText("<html>One or more digits are incorrect</html>");
        }

        return correct;
    }

    /**
     * I couldn't find a method to test it without throwing an error, so I made
     * one.
     *
     * @param num A String to test
     * @return True if the String represents an integer
     */
    private boolean isInteger(String num) {
        for (int i = 0; i < num.length(); i++) {
            if (!Character.isDigit(num.charAt(i))) {
                return false;
            }
        }

        return true;
    }

    /**
     * Checks whether the user input matches the ID's data. See
     * https://www.westerncape.gov.za/general-publication/decoding-your-south-african-id-number-0
     *
     * @return True if the data contained in the ID number matches the entered
     * data
     */
    private boolean compareIDToInput() {
        boolean correct = true;
        boolean oneIncorrect;

        //Check the date
        String formattedDate = formatDate(idNum.substring(0, 6), 20);
        LocalDate IDDate = LocalDate.parse(formattedDate);
        oneIncorrect = !IDDate.equals(DOB);

        //Exit if formatDate "throws" its "error"
        if (formattedDate.equals("0000-01-01")) {
            return false;
        }

        //Clunky way to check for people born in different centuries
        if (oneIncorrect) {
            IDDate = LocalDate.parse(formatDate(idNum.substring(0, 6), 19));
            oneIncorrect = !IDDate.equals(DOB);
        }
        if (oneIncorrect) {
            IDDate = LocalDate.parse(formatDate(idNum.substring(0, 6), 18));
            oneIncorrect = !IDDate.equals(DOB);
        }

        if (oneIncorrect) {
            lblDOBError.setText("<html>Date of birth doesn't match ID number</html>");
            correct = oneIncorrect = false;
        }

        //Check the gender
        char genderNum = idNum.charAt(6);
        boolean isFemale = genderNum < '5';
        oneIncorrect = isFemale ^ gender;

        if (oneIncorrect) {
            lblGenderError.setText("Gender doesn't match ID number");
            correct = oneIncorrect = false;
        }

        //Check the nationality
        char natNum = idNum.charAt(10);
        boolean isNative = natNum == '0';
        oneIncorrect = isNative
                ^ country.equals("South Africa");

        if (oneIncorrect) {
            lblCountryError.setText("<html>Nationality doesn't match ID number</html>");
            correct = oneIncorrect = false;
        }

        if (!(natNum == '0' || natNum == '1')) {
            lblCountryError.setText("<html>The third last digit must be 0 or 1</html>");
            correct = oneIncorrect = false;
        }

        return correct;
    }

    /**
     * Turns unparseable dates to parseable ones
     *
     * @param date Formatted as yyMMdd
     * @param century Century to be added to the beginning of the date
     * @return
     */
    private String formatDate(String date, int century) {
        String out = "" + century + date.substring(0, 2);

        out += "-" + date.substring(2, 4);
        out += "-" + date.substring(4, 6);

        try {
            LocalDate.parse(out, DateTimeFormatter.ofPattern("yyyy-MM-dd"));
        } catch (DateTimeParseException exept) {
            JOptionPane.showMessageDialog(this, "ID number date is impossible",
                    "Error", JOptionPane.ERROR_MESSAGE);
            lblIDNumError.setText("The first six digits are impossible");
            return "0000-01-01";
        }

        return out;
    }

    /**
     * Checks whether the age specified by the user matches their birth date
     *
     * @return True if the ages match
     */
    private boolean ageMatch() {
        boolean correct = true;

        Period timeDiff = Period.between(DOB, LocalDate.now());

        correct = age == timeDiff.getYears();

        if (!correct) {
            lblAgeError.setText("<html>Age doesn't match Date of Birth</html>");
            lblDOBError.setText("<html>Date of Birth doesn't match Age</html>");
            return false;
        }

        return true;
    }

    /**
     * Resets all error labels
     */
    private void resetErrors() {
        lblAgeError.setText("");
        lblCountryError.setText("");
        lblDOBError.setText("");
        lblGenderError.setText("");
        lblIDNumError.setText("");
    }

    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.ButtonGroup btnGroupGender;
    private javax.swing.JButton btnValidate;
    private javax.swing.JComboBox<String> comboCountry;
    private com.github.lgooddatepicker.components.DatePicker dtpDOB;
    private javax.swing.JLabel lblAge;
    private javax.swing.JLabel lblAgeError;
    private javax.swing.JLabel lblCountry;
    private javax.swing.JLabel lblCountryError;
    private javax.swing.JLabel lblDOB;
    private javax.swing.JLabel lblDOBError;
    private javax.swing.JLabel lblGender;
    private javax.swing.JLabel lblGenderError;
    private javax.swing.JLabel lblIDNum;
    private javax.swing.JLabel lblIDNumError;
    private javax.swing.JLabel lblTitle;
    private javax.swing.JRadioButton radioFemale;
    private javax.swing.JRadioButton radioMale;
    private javax.swing.JTextField txfAge;
    private javax.swing.JTextField txfCountry;
    private javax.swing.JTextField txfIDNum;
    // End of variables declaration//GEN-END:variables
}
